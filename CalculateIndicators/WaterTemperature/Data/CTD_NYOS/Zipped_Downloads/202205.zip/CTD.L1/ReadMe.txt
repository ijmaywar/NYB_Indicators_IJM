2205_TA_DIC are raw data from samples analyzed for TA and DIC on the Vindta 3c at Stony Brook University. Samples from NYOS 2205 were analyzed from June 1, 2022 to June 27, 2022. Sample analysis for each �set� of samples takes place over the course of 5 days. Day 1-2 are for DIC analysis and days 3-5 are for TA analysis of the same samples. CRM and our own lab standard (LS) were used to calibrate the system each day. Please refer to photos of lab logsheets for more details on any incidents that occurred while running samples. Issues encountered include: user error.

Btl_files contains CTD data that has been processed with Seabird�s Data Processing software and broken up by when each bottle during each cast was fired. 
 
Cnv contains all CTD data that has been processed with Seabird�s Data Processing
software. 
 
Digital water sampling log contains information on bottle samples, data from paper
logsheets and data from the CTD btl files. 
 
Spec_2205 contains raw pH data that was analyzed on the spectrophotometric pH system at
Stony Brook University.

